<h1 align=center>📱 Simple Calculator App on Android Studio</h1>

<p align=center>
<img src = "https://github.com/zumrudu-anka/android-studio-simple-calculator/blob/main/presentation/img1.png" alt="Screenshot" width = 400></img>
</p>
